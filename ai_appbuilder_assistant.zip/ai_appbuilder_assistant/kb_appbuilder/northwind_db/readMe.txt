You need to download the `northwind.db` file from  https://github.com/jpwhite3/northwind-SQLite3/tree/main/dist/northwind.db and put it in this folder.

You can read more about the `northwind.db` here, https://docs.yugabyte.com/preview/sample-data/northwind/
