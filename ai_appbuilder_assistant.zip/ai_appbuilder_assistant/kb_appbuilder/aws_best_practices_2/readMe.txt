You need to scrape and download the AWS well-architected framework as raw html text files and put it in this folder.


You can run the following notebook in the main directory of this package to scrape as text files and download in this folder
`scrape_aws_website_for_kb2_aws_well_architected_framework.ipynb` 